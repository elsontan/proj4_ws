^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot3_manipulation_hardware
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.0 (2022-10-14)
------------------
* Support ROS2 Foxy
* MoveIt environment configured (backported from Humble)
* use ros2_control framework instead of ROBOTIS custom library
* removed dependency to `turtlebot3_*`` and `open_manipulator` packages
* Contributors: Hye-Jong KIM, Darby Lim, Will Son
